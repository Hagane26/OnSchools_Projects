public class WorkBackground {

    public static String Login(String u_email, String u_pass){
        String va = u_email.toString() + " " + u_pass.toString();
        return va;
    }
}
